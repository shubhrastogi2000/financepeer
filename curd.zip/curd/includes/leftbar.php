	<nav class="ts-sidebar" style="background-color: lightgrey; color: blue;font-size: large;">
			<ul class="ts-sidebar-menu">

			<!-- <li class="ts-label">Main</li> -->
			<li><a href="profile.php"><i class="fa fa-user"></i> &nbsp;Profile</a>
			</li>
			<li><a href="json_file.php"><i class="fa fa-file-image-o"></i> &nbsp;Upload File</a>
			</li>
			<li><a href="feedback.php"><i class="fa fa-files-o"></i> &nbsp;Uploaded Files</a>
			</li>
			</ul>
		</nav>
